"use client"
import { useNavigate } from "react-router-dom"
import "./AdminNavBar.css"

const AdminNavBar = () => {
  const navigate = useNavigate()

  const handleLogout = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("userRole")
    navigate("/")
  }

  return (
    <nav className="admin-navbar">
      <div className="navbar-container">
        <div className="navbar-logo">
          <span className="logo-text">GIGI GUBAE - Admin</span>
        </div>

        <ul className="navbar-menu">
          <li>
            <a href="#" onClick={() => navigate("/admin/courses")}>
              Courses
            </a>
          </li>
          <li>
            <a href="#" onClick={() => navigate("/admin/create-course")}>
              Create Course
            </a>
          </li>
          <li>
            <a href="#" onClick={() => navigate("/admin/attendance")}>
              Mark Attendance
            </a>
          </li>
        </ul>

        <button className="logout-btn" onClick={handleLogout}>
          Logout
        </button>
      </div>
    </nav>
  )
}

export default AdminNavBar
