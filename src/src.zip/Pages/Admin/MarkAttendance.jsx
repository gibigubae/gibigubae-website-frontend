import React from 'react'

const MarkAttendance = () => {
  return (
    <div>MarkAttendance</div>
  )
}

export default MarkAttendance